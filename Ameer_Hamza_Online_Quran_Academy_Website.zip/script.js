const toggle = document.getElementById("menuToggle");
const nav = document.getElementById("nav");
toggle?.addEventListener("click", () => {
  const isOpen = nav.classList.toggle("open");
  toggle.setAttribute("aria-expanded", String(isOpen));
  toggle.setAttribute("aria-label", isOpen ? "Close navigation" : "Open navigation");
  toggle.textContent = isOpen ? "×" : "☰";
});
nav?.querySelectorAll("a").forEach(link => link.addEventListener("click", () => {
  nav.classList.remove("open");
  toggle?.setAttribute("aria-expanded", "false");
  if (toggle) { toggle.textContent = "☰"; toggle.setAttribute("aria-label", "Open navigation"); }
}));
document.getElementById("year").textContent = new Date().getFullYear();
