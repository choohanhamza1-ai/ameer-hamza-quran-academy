AMEER HAMZA ONLINE QURAN ACADEMY — WEBSITE FILES

Files:
- index.html: website content
- styles.css: responsive design and colors
- script.js: mobile menu and current footer year

IMPORTANT:
1. The WhatsApp contact link is set to the number supplied: 03293707887.
2. Images load from Unsplash and fonts load from Google Fonts, so those visual elements need an internet connection.
3. Check the website on your phone and test every WhatsApp button before sharing.
4. Update any wording or course details to match your real class offerings before publishing.

FREE HOSTING OPTION: GITHUB PAGES
A. On a browser, go to https://github.com and create/sign in to an account.
B. Create a new repository, for example: ameer-hamza-quran-academy
C. Upload index.html, styles.css, and script.js to the repository's root.
D. Open repository Settings → Pages.
E. Under Build and deployment, select "Deploy from a branch", choose branch "main" and folder "/ (root)", then Save.
F. Wait a few minutes. GitHub Pages will show the public website address in Settings → Pages.
G. Open that address on your phone and test the WhatsApp links.

No paid domain is required. GitHub's interface may change; if Pages is unavailable, follow the current official guide:
https://docs.github.com/en/pages/quickstart

You can also use Netlify Drop by uploading the site folder/zip at https://app.netlify.com/drop if that service's current free deployment flow is available to you.
